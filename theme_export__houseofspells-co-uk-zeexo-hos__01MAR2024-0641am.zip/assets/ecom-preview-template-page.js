

                (function(){
                    const Func = (function() {
                        if(!this.$el)return;const e=this.$el,t=e.querySelector(".ecom-text_view-more-btn"),i=e.querySelector(".ecom-text_view-less-btn"),n=e.querySelector(".text-content.ecom-html");!n||(t&&t.addEventListener("click",()=>{n.classList.remove("ecom-text--is-mark"),n.style.maxHeight="",t.style.display="none",i.style.display=""}),i&&i.addEventListener("click",()=>{n.classList.add("ecom-text--is-mark"),n.style.maxHeight="var(--ecom-description-height)",i.style.display="none",t.style.display=""}))
                    
                    });
                    const settings = {};
                    const ID = 'ecom-ce9fhzw9xvj';
                    document.querySelectorAll('.ecom-ce9fhzw9xvj').forEach(function(el){
                        Func.call({$el: el, settings, id:ID,isLive: true});
                    });
                })();
            
                (function(){
                    const Func = (function() {
                        if(!this.$el)return;const e=this.$el,t=e.querySelector(".ecom-text_view-more-btn"),i=e.querySelector(".ecom-text_view-less-btn"),n=e.querySelector(".text-content.ecom-html");!n||(t&&t.addEventListener("click",()=>{n.classList.remove("ecom-text--is-mark"),n.style.maxHeight="",t.style.display="none",i.style.display=""}),i&&i.addEventListener("click",()=>{n.classList.add("ecom-text--is-mark"),n.style.maxHeight="var(--ecom-description-height)",i.style.display="none",t.style.display=""}))
                    
                    });
                    const settings = {};
                    const ID = 'ecom-t54vrpo5boh';
                    document.querySelectorAll('.ecom-t54vrpo5boh').forEach(function(el){
                        Func.call({$el: el, settings, id:ID,isLive: true});
                    });
                })();
            
                (function(){
                    const Func = (function() {
                        if(!this.$el)return;const e=this.$el,t=e.querySelector(".ecom-text_view-more-btn"),i=e.querySelector(".ecom-text_view-less-btn"),n=e.querySelector(".text-content.ecom-html");!n||(t&&t.addEventListener("click",()=>{n.classList.remove("ecom-text--is-mark"),n.style.maxHeight="",t.style.display="none",i.style.display=""}),i&&i.addEventListener("click",()=>{n.classList.add("ecom-text--is-mark"),n.style.maxHeight="var(--ecom-description-height)",i.style.display="none",t.style.display=""}))
                    
                    });
                    const settings = {};
                    const ID = 'ecom-s08i12xj4vq';
                    document.querySelectorAll('.ecom-s08i12xj4vq').forEach(function(el){
                        Func.call({$el: el, settings, id:ID,isLive: true});
                    });
                })();
            
            if(window.location.search.indexOf("ecom-token=") < 0)
            {
                document.querySelector(".ecom-builder").innerHTML = '<h3 style="width:100%;display:block;text-align:center">This template for preview purposes only</h3>';
                document.querySelector("body").style.opacity= "0.7";
            }
            if(window.Shopify && window.Shopify.theme && window.Shopify.theme.id){
                const url = new URL(window.location);
                url.searchParams.set('preview_theme_id',  window.Shopify.theme.id);
                window.history.pushState({}, '', url);
            }
        