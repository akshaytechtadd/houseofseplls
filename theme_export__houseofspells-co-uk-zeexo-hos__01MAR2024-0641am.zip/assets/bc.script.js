var AT_Main = {

  getWidthBrowser : function() { // Get width browser
    var myWidth;

    if( typeof( window.innerWidth ) == 'number' ) {
      //Non-IE
      myWidth = window.innerWidth;
    }
    else if( document.documentElement && ( document.documentElement.clientWidth || document.documentElement.clientHeight ) ) {
      //IE 6+ in 'standards compliant mode'
      myWidth = document.documentElement.clientWidth;
    }
    else if( document.body && ( document.body.clientWidth || document.body.clientHeight ) ) {
      //IE 4 compatible
      myWidth = document.body.clientWidth;
    }

    return myWidth;
  },

  stickMenu : function() {
    var enable_stick = jQuery(".header-content").data('stick');
    var enable_stick_mobile = jQuery(".header-content").data('stickymobile');

    if(enable_stick && AT_Main.getWidthBrowser() > 991){
      //Keep track of last scroll
      var lastScroll = 0;
      var header = jQuery(".header-container");
      var body_content = jQuery("#body-content");

      if($('.header-content').hasClass('header-overlay')){
        var _closeBar = $('#shopify-section-announcement-bar').height();
        if(_closeBar == null){
          _closeBar = 250;
        }
        jQuery(window).scroll(function() {
          //Sets the current scroll position
          var st = jQuery(this).scrollTop();
          //Determines up-or-down scrolling
          if (st > lastScroll) {

            //Replace this with your function call for downward-scrolling
            if (st > _closeBar ) {
              header.addClass("header-fixed");
              body_content.addClass("has-header-fixed");
            }
          }
          else {
            //Replace this with your function call for upward-scrolling
            if (st < _closeBar) {
              header.removeClass("header-fixed");
              body_content.removeClass("has-header-fixed");
            }
          }
          //Updates scroll position
          lastScroll = st;
        });
      }
      else{
        jQuery(window).scroll(function() {
          //Sets the current scroll position
          var st = jQuery(this).scrollTop();
          //Determines up-or-down scrolling
          if (st > lastScroll) {

            //Replace this with your function call for downward-scrolling
            if (st > 250 ) {
              header.addClass("header-fixed");
              body_content.addClass("has-header-fixed");
            }
          }
          else {
            //Replace this with your function call for upward-scrolling
            if (st < 250) {
              header.removeClass("header-fixed");
              body_content.removeClass("has-header-fixed");
            }
          }
          //Updates scroll position
          lastScroll = st;
        });
      }
    }

    if(enable_stick_mobile && AT_Main.getWidthBrowser() < 992){

      //Keep track of last scroll
      if($("body").hasClass("templateCart")){
        var lastScroll = 0;
        var header = jQuery(".mobile-total-price");
        var body_content = jQuery("#body-content");

        jQuery(window).scroll(function() {
          //Sets the current scroll position
          var st = jQuery(this).scrollTop();
          //Determines up-or-down scrolling
          if (st > lastScroll) {

            //Replace this with your function call for downward-scrolling
            if (st > 350 ) {
              header.addClass("header-mobile-fixed");
              body_content.addClass("has-header-fixed");
            }
          }
          else {
            //Replace this with your function call for upward-scrolling
            if (st < 350) {
              header.removeClass("header-mobile-fixed");
              body_content.removeClass("has-header-fixed");
            }
          }
          //Updates scroll position
          lastScroll = st;
        });
      }

      else{
        var lastScroll = 0;
        var header = jQuery(".header-container");
        var body_content = jQuery("#body-content");

        jQuery(window).scroll(function() {
          //Sets the current scroll position
          var st = jQuery(this).scrollTop();
          //Determines up-or-down scrolling
          if (st > lastScroll) {

            //Replace this with your function call for downward-scrolling
            if (st > 250 ) {
              header.addClass("header-mobile-fixed");
              body_content.addClass("has-header-fixed");
            }
          }
          else {
            //Replace this with your function call for upward-scrolling
            if (st < 250) {
              header.removeClass("header-mobile-fixed");
              body_content.removeClass("has-header-fixed");
            }
          }
          //Updates scroll position
          lastScroll = st;
        });
      }
    }
  },

  stickAddToCart : function() {
    $(window).on( 'scroll' , function() {
      var ps = jQuery(this).scrollTop();
      var _show_sticky = ($('#add-to-cart').offset().top);

      if ( _show_sticky < ps ) {
        $('.add-to-cart-sticky').addClass('show');
      }
      else {
        $('.add-to-cart-sticky').removeClass('show');
      }
    });
  },

  toTopButton : function(){
    var to_top_btn = $("#scroll-to-top");
    if( 1 > to_top_btn.length ){
      return;
    }
    $(window).on( 'scroll' , function() {
      var b = jQuery(this).scrollTop();
      var c = jQuery(this).height();
      if (b > 100) {
        var d = b + c / 2;
      }
      else {
        var d = 1 ;
      }

      if (d < 1000 && d < c) {
        jQuery("#scroll-to-top").removeClass('on off').addClass('off');
      } else {
        jQuery("#scroll-to-top").removeClass('on off').addClass('on');
      }
    });

    to_top_btn.on( 'click',function (e) {
      e.preventDefault();
      jQuery('body,html').animate({scrollTop:0},800,'swing');
    });
  },

  addEvent : function(obj, evt, fn){ // Exit intent
    if (obj.addEventListener) {
      obj.addEventListener(evt, fn, false);
    }
    else if (obj.attachEvent) {
      obj.attachEvent("on" + evt, fn);
    }
  },

  exitIntent : function(){  // Exit intent trigger
    AT_Main.addEvent(document, 'mouseout', function(evt) {

      if (evt.toElement == null && evt.relatedTarget == null ) {
        AT_Main.newsletterPopupAction();
      };

    });
  },

  newsletterPopupAction : function(){ // Action newsletter popup
    let expire = jQuery("#newsletter-popup").data('expires');

    if (jQuery.cookie('mycookie')) {
      //it hasn't been one days yet
    }
    else {
      $.fancybox.open({
        src  : '#newsletter-popup'
        ,type : 'inline'
        ,autoDimensions: false
        ,width    : 'auto'
        ,height   : 'auto'
        ,closeBtn    : false
      })
    }
    jQuery.cookie('mycookie', 'true', { expires: expire });
  },

  newsletterPopupDelayAction : function(){ // Action newsletter popup with delay time
    let delay = jQuery("#newsletter-popup").data('delay');
    let expire = jQuery("#newsletter-popup").data('expires');

    if (jQuery.cookie('mycookie')) {
      //it hasn't been one days yet
    }
    else {
        setTimeout(function(){
          $.fancybox.open({
            src  : '#newsletter-popup'
            ,type : 'inline'
            ,autoDimensions: false
            ,width    : 'auto'
            ,height   : 'auto'
            ,closeBtn    : false
          })
        }, delay);

    }
    jQuery.cookie('mycookie', 'true', { expires: expire });
  },

  newsletterPopup : function(){ // Show newsletter popup
    let style = jQuery("#newsletter-popup").data('style');

    if ($('.newsletter-popup-content').length > 0){
      if (style == 'delay'){
        AT_Main.newsletterPopupDelayAction();
      }

      else if (style == 'exit-intent'){
        AT_Main.exitIntent();
      }

      else{
        jQuery(window).scroll(function() {
          let scroll_position = jQuery("#newsletter-popup").data('scroll');
          let newsletter_st = jQuery(this).scrollTop();

          if (newsletter_st > scroll_position ) {
            AT_Main.newsletterPopupAction();
          }
        });
      }

      jQuery('.np-close').on('click',function (e) {
        $('#newsletter-popup .fancybox-close-small').trigger('click');
      })
    }
    else {return ;}
  },

  newsletterCoupon: function(){ // Show coupon code when subscribe newsletter'
    
    if ($('#newsletter-popup .newsletter-block--form-type').data('form-type') == 'klaviyo'){
      KlaviyoSubscribe.attachToForms('#newsletter-popup form', {
        success: function ($form) {
          jQuery('.text-box-image').hide();
          jQuery('.subscribe-result').show();
          jQuery('.newsletter-popup-content').removeClass('block-image-true').addClass('block-image-false');
        }
      });
    }
    else{

      jQuery('#mc-button').on('click', function (event) {
        if (event) event.preventDefault()
        let $form = $('#mc-form');

        jQuery.ajax({
          type: 'POST',
          url: $form.attr('action'),
          data: $form.serialize(),
          cache: false,
          dataType: 'json',
          contentType: 'application/json; charset=utf-8',
          error: function (err) { alert('Could not connect to the registration server. Please try again later.') },
          success: function (data) {
            jQuery('.text-box-image').hide();
            jQuery('.subscribe-result').show();
            jQuery('.newsletter-popup-content').removeClass('block-image-true').addClass('block-image-false');
          }
        })
      })
    }

    jQuery('.btn-copy').on('click',function (e) {
      var _temp = $('<input>');
      $("body").append(_temp);
      _temp.val($('#mycode').text()).select();
      document.execCommand("copy");
      _temp.remove();
    })
  },

  navMarginHeader : function(){ // Add margin to Navigation in Header Style 14
    if($('.header-container').hasClass('style-14')){
      setTimeout(function(){
        var _position_logo = $('.header-logo').position().left;
        var _position_vertical_menu = $('.vertical-menu').position().left;
        var _position = _position_vertical_menu - _position_logo;
        _position = _position + 'px';
        $('.header-content .style-14 .header-navigation .table-row').css('margin-left', _position);
      },1200);
    }

    if($('.content-container').hasClass('container') && $('.bc-home-slideshow').length > 0){
      var _bc_wrapper_position = $('.bc-home-slideshow').position().left;
      var _two_column_position = $('.two-column-content-position').position().left;
      var _block_categories_position = _two_column_position - _bc_wrapper_position;
      _block_categories_position = _block_categories_position + 'px';

      $('.bc-home-slideshow .block-categories').css('left', _block_categories_position);
    }
  },

  searchBox : function(){
    $(".search-icon-desktop > a > i").click(function () {
      $(this).parents('.search-icon-desktop').toggleClass("active");
    });
  },

  smartSearch : function(){ // fix search page when disable Smart Search
    if ((jQuery("body").hasClass('snize-results-page')) && (!jQuery("body").hasClass('as-smart'))){
      var _base_url = window.location.origin;
      var _url = window.location.href;
      var splitStr = _url.substring(_url.indexOf('?') + 1);
      window.location.href = _base_url + '/search?type=product&' + splitStr;
    }
  },

  toggleVerticalMenu : function(){
    jQuery('.vertical-menu .head, .vertical-navbar').hover(function(){
      jQuery('.vertical-menu .head').addClass('opened');
      jQuery('.vertical-navbar').addClass('opened');
    },function(){
      jQuery('.vertical-menu .head').removeClass('opened');
      jQuery('.vertical-navbar').removeClass('opened');
    });
  },

  toggleCartSidebar : function(){
    jQuery('.cart-toggle').on('click',function (e) {
      e.stopPropagation();
      AT_Main.fixNoScroll();
      jQuery('.cart-sb').toggleClass('opened');
      jQuery('body').toggleClass('cart-opened');
    });

    jQuery('#page-body, .c-close').on('click',function () {
      jQuery('.cart-sb').removeClass('opened');
      jQuery('html,body').removeClass('cart-opened');

      AT_Main.fixReturnScroll();
    });
  },

  toggleFilterSidebar : function(){
    jQuery('.filter-icon.toggle').on('click',function (e) {
      jQuery('.filter-sidebar.position-body').slideToggle("slow");
    });

    jQuery('.filter-icon.drawer').on('click',function (e) {
      e.stopPropagation();
      AT_Main.fixNoScroll();
      jQuery('body').toggleClass('sidebar-opened');
    });

    jQuery('.f-close').on('click',function () {
      jQuery('#sidebar').removeClass('opened');
      jQuery('html,body').removeClass('sidebar-opened');
      AT_Main.fixReturnScroll();
    });

    jQuery('.filter-icon-order.toggle').on('click',function (e) {
      jQuery('.filter-order-form').slideToggle("slow");
    });

    jQuery('.filter-icon-order.drawer').on('click',function (e) {
      e.stopPropagation();
      AT_Main.fixNoScroll();
      jQuery('body').toggleClass('order-sidebar-opened');
    });

    jQuery('.fof-close').on('click',function () {
      jQuery('html,body').removeClass('order-sidebar-opened');
      AT_Main.fixReturnScroll();
    });

    jQuery('.style-accordion').on('click', '.sb-filter', function(n){ // Handle accordion in sidebar filter
      $(this).toggleClass('accordion-active');
      $(this).find('.advanced-filters').slideToggle('slow');
    });
  },

  handleSidebarWidthCollection : function(){ // handle width of sidebar on collection page
    if($('#page-body').hasClass('wide-padding') && AT_Main.getWidthBrowser() > 1440 ){
      $('.page-cata .left-column-container').removeClass('col-lg-3').addClass('col-lg-2');
      $('.page-cata .main-cata-page').removeClass('col-lg-9').addClass('col-lg-10');
    }

    else{
      $('.page-cata .left-column-container').removeClass('col-lg-2').addClass('col-lg-3');
      $('.page-cata .main-cata-page').removeClass('col-lg-10').addClass('col-lg-9');
    }
  },

  handleGridList : function(){

    if ($.cookie('cata-grid-4') == "yes") {
      jQuery(".page-cata").removeClass("cata-grid-1 cata-grid-1-v2 cata-grid-2 cata-grid-2-v2 cata-grid-3 cata-grid-5");
      $(".page-cata").addClass("cata-grid-4");
      $('.grid').each(function() {
        $(this).removeClass("active");
      });
      $('.grid-4').addClass("active");
      console.log('ss');
    }

    if ($.cookie('cata-grid-5') == "yes") {
      jQuery(".page-cata").removeClass("cata-grid-1 cata-grid-1-v2 cata-grid-2 cata-grid-2-v2 cata-grid-3 cata-grid-4");
      $(".page-cata").addClass("cata-grid-5");
      $('.grid').each(function() {
        $(this).removeClass("active");
      });
      $('.grid-5').addClass("active");
    }

    if ($.cookie('cata-grid-3') == "yes") {
      jQuery(".page-cata").removeClass("cata-grid-1 cata-grid-1-v2 cata-grid-2 cata-grid-2-v2 cata-grid-4 cata-grid-5");
      $(".page-cata").addClass("cata-grid-3");
      $('.grid').each(function() {
        $(this).removeClass("active");
      });
      $('.grid-3').addClass("active");
    }

    if ($.cookie('cata-grid-2') == "yes") {
      jQuery(".page-cata").removeClass("cata-grid-1 cata-grid-1-v2 cata-grid-2-v2 cata-grid-3 cata-grid-4 cata-grid-5");
      $(".page-cata").addClass("cata-grid-2");
      $('.grid').each(function() {
        $(this).removeClass("active");
      });
      $('.grid-2').addClass("active");
    }

    if ($.cookie('cata-grid-2-v2') == "yes") {
      jQuery(".page-cata").removeClass("cata-grid-1 cata-grid-1-v2 cata-grid-2 cata-grid-3 cata-grid-4 cata-grid-5");
      $(".page-cata").addClass("cata-grid-2-v2");
      $('.grid').each(function() {
        $(this).removeClass("active");
      });
      $('.grid-2-v2').addClass("active");
    }

    if ($.cookie('cata-grid-1') == "yes") {
      jQuery(".page-cata").removeClass("cata-grid-1-v2 cata-grid-2 cata-grid-2-v2 cata-grid-3 cata-grid-4 cata-grid-5");
      $(".page-cata").addClass("cata-grid-1");
      $('.grid').each(function() {
        $(this).removeClass("active");
      });
      $('.grid-1').addClass("active");
    }

    if ($.cookie('cata-grid-1-v2') == "yes") {
      jQuery(".page-cata").removeClass("cata-grid-1 cata-grid-2 cata-grid-2-v2 cata-grid-3 cata-grid-4 cata-grid-5");
      $(".page-cata").addClass("cata-grid-1-v2");
      $('.grid').each(function() {
        $(this).removeClass("active");
      });
      $('.grid-1-v2').addClass("active");
    }

    jQuery("body").on("click", ".grid-4", function() {
        $.cookie('cata-grid-3','no',  {expires: 1, path: '/'});
        $.cookie('cata-grid-2','no',  {expires: 1, path: '/'});
        $.cookie('cata-grid-2-v2','no',  {expires: 1, path: '/'});
        $.cookie('cata-grid-1','no',  {expires: 1, path: '/'});
        $.cookie('cata-grid-1-v2','no',  {expires: 1, path: '/'});
        $.cookie('cata-grid-4','yes', {expires: 1, path: '/'});
        $.cookie('cata-grid-5','no',  {expires: 1, path: '/'});
        jQuery(".page-cata").removeClass("cata-grid-1 cata-grid-1-v2 cata-grid-2 cata-grid-2-v2 cata-grid-3 cata-grid-5");
        jQuery(".page-cata").addClass("cata-grid-4");

        var e = jQuery(this).closest(".grid-list");
        e.children('.grid').each(function() {
          $(this).removeClass("active");
        });
        $(this).addClass("active");

    }),jQuery("body").on("click", ".grid-5", function() {
        $.cookie('cata-grid-4','no',  {expires: 1, path: '/'});
        $.cookie('cata-grid-3','no',  {expires: 1, path: '/'});
        $.cookie('cata-grid-2','no',  {expires: 1, path: '/'});
        $.cookie('cata-grid-2-v2','no',  {expires: 1, path: '/'});
        $.cookie('cata-grid-1','no',  {expires: 1, path: '/'});
        $.cookie('cata-grid-1-v2','no',  {expires: 1, path: '/'});
        $.cookie('cata-grid-5','yes', {expires: 1, path: '/'});

        jQuery(".page-cata").removeClass("cata-grid-1 cata-grid-1-v2 cata-grid-2 cata-grid-2-v2 cata-grid-3 cata-grid-4");
        jQuery(".page-cata").addClass("cata-grid-5");

        var e = jQuery(this).closest(".grid-list");
        e.children('.grid').each(function() {
          $(this).removeClass("active");
        });
        $(this).addClass("active");

    }),jQuery("body").on("click", ".grid-3", function() {
        $.cookie('cata-grid-5','no',  {expires: 1, path: '/'});
        $.cookie('cata-grid-4','no',  {expires: 1, path: '/'});
        $.cookie('cata-grid-2','no',  {expires: 1, path: '/'});
        $.cookie('cata-grid-2-v2','no',  {expires: 1, path: '/'});
        $.cookie('cata-grid-1','no',  {expires: 1, path: '/'});
        $.cookie('cata-grid-1-v2','no',  {expires: 1, path: '/'});
        $.cookie('cata-grid-3','yes', {expires: 1, path: '/'});

        jQuery(".page-cata").removeClass("cata-grid-1 cata-grid-1-v2 cata-grid-2 cata-grid-2-v2 cata-grid-4 cata-grid-5");
        jQuery(".page-cata").addClass("cata-grid-3");

        var e = jQuery(this).closest(".grid-list");
        e.children('.grid').each(function() {
          $(this).removeClass("active");
        });
        $(this).addClass("active");

    }),jQuery("body").on("click", ".grid-2", function() {
        var e = jQuery(this).closest(".grid-list");
        $.cookie('cata-grid-5','no',  {expires: 1, path: '/'});
        $.cookie('cata-grid-4','no',  {expires: 1, path: '/'});
        $.cookie('cata-grid-3','no',  {expires: 1, path: '/'});
        $.cookie('cata-grid-2-v2','no',  {expires: 1, path: '/'});
        $.cookie('cata-grid-1','no',  {expires: 1, path: '/'});
        $.cookie('cata-grid-1-v2','no',  {expires: 1, path: '/'});
        $.cookie('cata-grid-2','yes', {expires: 1, path: '/'});

        jQuery(".page-cata").removeClass("cata-grid-1 cata-grid-1-v2 cata-grid-2-v2 cata-grid-3 cata-grid-4 cata-grid-5");
        jQuery(".page-cata").addClass("cata-grid-2");

        var e = jQuery(this).closest(".grid-list");
        e.children('.grid').each(function() {
          $(this).removeClass("active");
        });
        $(this).addClass("active");

    }),jQuery("body").on("click", ".grid-2-v2", function() {
        var e = jQuery(this).closest(".grid-list");
        $.cookie('cata-grid-5','no',  {expires: 1, path: '/'});
        $.cookie('cata-grid-4','no',  {expires: 1, path: '/'});
        $.cookie('cata-grid-3','no',  {expires: 1, path: '/'});
        $.cookie('cata-grid-2','no',  {expires: 1, path: '/'});
        $.cookie('cata-grid-1','no',  {expires: 1, path: '/'});
        $.cookie('cata-grid-1-v2','no',  {expires: 1, path: '/'});
        $.cookie('cata-grid-2-v2','yes', {expires: 1, path: '/'});

        jQuery(".page-cata").removeClass("cata-grid-1 cata-grid-1-v2 cata-grid-2 cata-grid-3 cata-grid-4 cata-grid-5");
        jQuery(".page-cata").addClass("cata-grid-2-v2");

        var e = jQuery(this).closest(".grid-list");
        e.children('.grid').each(function() {
          $(this).removeClass("active");
        });
        $(this).addClass("active");

    }),jQuery("body").on("click", ".grid-1", function() {
        var e = jQuery(this).closest(".grid-list");
        $.cookie('cata-grid-5','no',  {expires: 1, path: '/'});
        $.cookie('cata-grid-4','no',  {expires: 1, path: '/'});
        $.cookie('cata-grid-3','no',  {expires: 1, path: '/'});
        $.cookie('cata-grid-2','no',  {expires: 1, path: '/'});
        $.cookie('cata-grid-2-v2','no',  {expires: 1, path: '/'});
        $.cookie('cata-grid-1-v2','no',  {expires: 1, path: '/'});
        $.cookie('cata-grid-1','yes', {expires: 1, path: '/'});

        jQuery(".page-cata").removeClass("cata-grid-1-v2 cata-grid-2 cata-grid-2-v2 cata-grid-3 cata-grid-4 cata-grid-5");
        jQuery(".page-cata").addClass("cata-grid-1");

        var e = jQuery(this).closest(".grid-list");
        e.children('.grid').each(function() {
          $(this).removeClass("active");
        });
        $(this).addClass("active");
    }),jQuery("body").on("click", ".grid-1-v2", function() {
        var e = jQuery(this).closest(".grid-list");
        $.cookie('cata-grid-5','no',  {expires: 1, path: '/'});
        $.cookie('cata-grid-4','no',  {expires: 1, path: '/'});
        $.cookie('cata-grid-3','no',  {expires: 1, path: '/'});
        $.cookie('cata-grid-2','no',  {expires: 1, path: '/'});
        $.cookie('cata-grid-2-v2','no',  {expires: 1, path: '/'});
        $.cookie('cata-grid-1','no',  {expires: 1, path: '/'});
        $.cookie('cata-grid-1-v2','yes', {expires: 1, path: '/'});

        jQuery(".page-cata").removeClass("cata-grid-1 cata-grid-2 cata-grid-2-v2 cata-grid-3 cata-grid-4 cata-grid-5");
        jQuery(".page-cata").addClass("cata-grid-1-v2");

        var e = jQuery(this).closest(".grid-list");
        e.children('.grid').each(function() {
          $(this).removeClass("active");
        });
        $(this).addClass("active");
    })
  },

  handleOrderFormQty : function(){
    jQuery("body").on("click",".global-product-info-qty-plus",function(){
      q = $(this).prev();
      var value = parseInt(q.val(), 10);
      value = isNaN(value) ? 0 : value;
      value++;
      q.val(value);
    });

    jQuery("body").on("click",".global-product-info-qty-minus",function(){
      q = $(this).next();
      var value = parseInt(q.val(), 10);
      value = isNaN(value) ? 1 : value;
      if(value > 1){
        value--;
        q.val(value);
      }
    });
  },

  effectNavigation : function(){ // Make hover effect of navigation
    jQuery(".top-account-holder").hover(function(e){
      jQuery(this).find('>.dropdown-menu').addClass("fadeInUp animated");
    },function(e){
      jQuery(this).find('>.dropdown-menu').removeClass("fadeInUp animated");
    });

    jQuery(".currency-block").hover(function(e){
      jQuery(this).find('>.dropdown-menu').addClass("fadeInUp animated");
    },function(e){
      jQuery(this).find('>.dropdown-menu').removeClass("fadeInUp animated");
    });

    jQuery('#city-phone-numbers').on("change", function(e) {
      var _newcity = jQuery(e.currentTarget).find(':selected').attr('value');
      $('#city-phone-number-label').html(_newcity);
    });

    if ($('.top-bar-right ul.menu li').length === 0 ){
      jQuery('.top-bar-right .menu').remove();
    }
  },

  menuOnMobileNew : function(){ // handle new menu on mobile

    if($('.mobile-version .mega-menu .position-left').length > 0 || $('.mobile-version .mega-menu .position-center').length > 0 || $('.mobile-version .mega-menu .position-right').length > 0){
      $('.mobile-version .mega-menu .mega-col').each(function(){
        $(this).parents('.row').first().before($(this).children());
      })
      $('.mobile-version .mega-menu .row').remove();
    }

    if($('.mobile-version .mega-menu .menu-proudct-carousel').length > 0){
      setTimeout(function(){
        $('.mobile-version .mega-menu .menu-proudct-carousel').prepend('<li class="back-prev-menu"><span class="expand back">Back</span></li>');
      },500);
    }

    jQuery(document).on('click','.mobile-version .menu-mobile .main-nav .expand',function(event){

      let _title = $(this).parents('.dropdown').first().find('a').first().children().first().text().split('\n')[0];
      let e = $(this).parents('.dropdown').first();

      e.addClass('active');
      e.parent().addClass('sub-open');

      if (e.hasClass('dropdown') ) {
        let child = e.children('.dropdown-menu');
        if(child.length > 0){
          if (child.hasClass('menu-mobile-open') == false) {
            child.addClass('menu-mobile-open');

            if (_title.length > 0) {
              child.children('.back-prev-menu').find('.back').html(_title);
            }
            return false;
          }
        }
      }

      if ($(this).parent().hasClass('back-prev-menu')) {
        let e = $(this).parent();
        let _pa = e.parents('.dropdown').first();

        $(this).parents('.dropdown-menu').first().removeClass('menu-mobile-open');

        _pa.removeClass('active');
        _pa.parent().removeClass('sub-open');
      }
    });

    jQuery(document).on('click','.ci-store-info',function(e){
      jQuery('.contactbar-info').toggleClass('active');
    });

    jQuery(document).on('click','.contactbar-info-close',function(e){
      jQuery('.contactbar-info').removeClass('active');
    });

  },

  megamenuWithTabs : function(){

    jQuery(document)
    .on('mouseover','header li.mega-menu, header .menu-list li'  ,e=>$(e.currentTarget).addClass('mega-is-hover'))
    .on('mouseleave','header li.mega-menu, header .menu-list li' ,e=>(!$(e.currentTarget).hasClass('admin-editor--viewing') && $(e.currentTarget).removeClass('mega-is-hover')))

    .on('shopify:block:select','header li.mega-menu, header .menu-list li, header .mega-tab-item',   e=>{
      $(e.currentTarget).addClass('mega-is-hover admin-editor--viewing');

      if ($(e.currentTarget).closest('.vertical-menu').length) {
        $('.vertical-menu .head:not(.opened)').trigger('click');
      }

      if ($(e.currentTarget).closest('.dropdown-menu-tabs').length) {
        let _this = $(e.currentTarget);
        if (_this.attr('id') != undefined || _this.attr('data-id') != undefined) {
          let _id = _this.attr('id') || _this.attr('data-id');

          $('.title-item').removeClass('active');
          $('.tab-content-inner').removeClass('active');
          $('li[data-id="'+_id+'"]').addClass('active');
          $('.'+_id).addClass('active');
        }
      }
    })
    .on('shopify:block:deselect','header li.mega-menu, header .menu-list li', e=>{
      $(e.currentTarget).removeClass('mega-is-hover admin-editor--viewing');
      if ($(e.currentTarget).closest('.dropdown-menu-tabs').length) {
        $('.title-item, .tab-content-inner').removeClass('active');
        $('.title-item-1, .mm-tabs-1').addClass('active');
      }
    })


    jQuery(".tab-title .title-item").hover(function(e){
      $('.title-item').removeClass('active');
      $('.tab-content-inner').removeClass('active');

      var _class = $(this).attr('data-id');
      var idclass = "." + _class;
      var e = jQuery(this);

      e.addClass('active');
      $(idclass).addClass('active');
    });

    jQuery(".mega-menu").mouseleave(function(){
      $('.title-item, .tab-content-inner').removeClass('active');
      $('.title-item-1, .mm-tabs-1').addClass('active');
    });

    var _menu_shadow = $('.header-content').data('shadow');
    if(_menu_shadow){
      jQuery(".navbar .menu-list li.dropdown, .navbar .menu-list li.dropdown .dropdown-menu > li, .vertical-menu li.dropdown").hover(function(){
          $('#menu-hover-background').addClass('active');
      },function(){
        $('#menu-hover-background').removeClass('active');
      });
    }
  },

  megamenuDropwdownPosition : function(){ // Positioning otchf dropdown menu

    if($('.vertical-navbar').attr('data-height')){
      jQuery(".vertical-navbar .main-nav li.mega-menu").hover(function(){
        var _dropdown_height = $(this).find('.dropdown-menu').outerHeight();
        $('.vertical-menu .sidemenu-holder .navbar').css("min-height", _dropdown_height);
      });
    }

    jQuery(".navbar .menu-list li.mega-menu").hover(function(){
      var _check_rtl = JSON.parse($('body').attr('data-check-rtl'));
      var _dropdown_position = $(this).find('.dropdown-position');
      var _width = _dropdown_position.attr('data-width');
      var _fix_position = $('.header-content .header-main .table-row');

      if(_width < 100){
        _fix_position.css("position", "relative");
        var x = $(this).position();
        var _width_li = $(this).width();
        var _width_dropdown = $(this).width();
        var _position = '-' + (_dropdown_position.width() - _width_li) + 'px';
        var _position_division = '-' + ((_dropdown_position.width() - _width_li)/2) + 'px';

        if(_dropdown_position.hasClass('position-left')){
          if(_check_rtl){
            console.log('1');
            var _position_right = AT_Main.getWidthBrowser() - x.left - _width_li -20;
            _dropdown_position.css("right", _position_right);
          } else{
            _dropdown_position.css("left", x.left);
            console.log('2');
          }
        }

        else if(_dropdown_position.hasClass('position-right')){
          _dropdown_position.css("margin-left", _position);
        }

        else{
          //_dropdown_position.css("margin-left", _position_division);
        }
      }
    },function(){
      var _fix_position = $('.header-content .header-main .table-row');
      _fix_position.css("position", "unset");
    });
  },

  fixNoScroll : function() { // Fixed persitent position of page when scroll disapear
    var windowW = jQuery(window).width();
    jQuery('#page-body, .header-content, #page-body .mobile-version').css("width", windowW + 'px');
  },

  fixReturnScroll : function() {
    jQuery('#page-body, .header-content,#page-body .mobile-version').attr('style', '');
  },

  fixButton : function(){
    jQuery(".product-wrapper .product-head").each(function(e){
      if($(this).children().hasClass('wrapper-countdown')){
        $(this).find('.product-button').addClass('fix');
      }
    });
  },

  handleReviews: function() {
      SPR.registerCallbacks(), SPR.initRatingHandler(), SPR.initDomEls(), SPR.loadProducts(), SPR.loadBadges();
  },

  menuOnMobile : function(){
    jQuery(document).on('click',function(e){
      //alert(e.target.className);
    });

    jQuery('.mobile-cart-action .btn').on('click',function (e) { // hanlde mobile cart total price on cart page
      $('.btn-checkout').trigger('click');
    })

    jQuery('.currency_icon_mobile').on('click',function () {
      jQuery(".menu-mobile").removeClass("opened");
      jQuery("html,body").removeClass("menu-opened");
    });

    jQuery('#body-content').on('click',function () {
      jQuery(".menu-mobile").removeClass("opened");
      jQuery("html,body").removeClass("menu-opened");
            jQuery(".dropdown").removeClass("menu-mobile-open");
      AT_Main.fixReturnScroll();
    });

    jQuery('.mm-block-icons .wishlist-target, .mm-block-icons .compare-target').on('click',function () {
      jQuery(".menu-mobile").removeClass("opened");
      jQuery("html,body").removeClass("menu-opened");
      AT_Main.fixReturnScroll();
    });

    jQuery(document).on('click','.responsive-menu',function(e){
      e.stopPropagation();
      AT_Main.fixNoScroll();
      jQuery(".menu-mobile").toggleClass("opened");
      jQuery("html,body").toggleClass("menu-opened")
    });
    
    // jQuery(".navbar .menu-list li").hover(function(){jQuery(this).addClass("hover")},function(){jQuery(this).removeClass("hover")});

    jQuery(document).on('click','.sb-menu .expand',function(){
      var e=jQuery(this).parents(".dropdown").first();
      if (e.hasClass("s-open")) {
          e.removeClass("s-open");
      } else {
          e.addClass("s-open");
      }
    })

    jQuery(document).on('click','.currency_wrapper',function(){
      if ($('.currencies-dropdown').hasClass("opened")) {
          $('.currencies-dropdown').removeClass("opened");
          $(this).removeClass("icon-opened");
      } else {
          $('.currencies-dropdown').addClass("opened");
          $(this).addClass("icon-opened");
      }
    });

    jQuery(document).on('click','.bc-toggle',function(){
      var e=jQuery(this);
      if (e.hasClass("opened")) {
          e.removeClass("opened");
      } else {
          e.addClass("opened");
      }
    });

    jQuery(document).on('click','.top-cart-holder.hover-dropdown .cart-target',function(){
      var e=jQuery(this);
      if (e.hasClass("opened")) {
          e.removeClass("opened");
      } else {
          e.addClass("opened");
      }
    });
  },

  handleMenuMultiLine : function() {
    var outItem = "";
    var down = false;
    var top = 0;

    jQuery(".navbar-collapse .main-nav > li").on("mousemove", function(e){
      var target = jQuery(e.currentTarget);

      if( down && outItem != "") {
        outItem.addClass("hold");
        setTimeout(function(){
          if(outItem != "")
          outItem.removeClass("hold");
          down = false;
          outItem = "";
        },500);

        if( (outItem[0] == target[0]) || (outItem.offset().top == target.offset().top) )
        {
          outItem.removeClass("hold");
          down = false;
          outItem = "";
        }
      }
      else {
        outItem = "";
      }

    });

    jQuery(".navbar-collapse .main-nav >li").on("mouseout", function(e){

      var target = jQuery(e.currentTarget);

      if( e.pageY >= target.offset().top + 50 ) { //move down
        down = true;
      }

      if( target.hasClass("dropdown") ) { //target has child

        if(outItem == "")
          outItem = target;
      }

    });
  },

  lookbooks_initor : function(){ // handle lookbook section
    if( jQuery('.lookbook-section .lookbook-content .row').length > 0 ){

      $(".lookbook-content .pin .open-pin").click(function () {
        if($(this).parent().hasClass("active")) {
          $(this).parent().removeClass("active");
        } else {
          $(".lookbook-content .pin").removeClass("active");
          $(this).parent().addClass("active");
        }
        return false;
      });

      $('html').on('click', function () {
        $(".lookbook-content .pin").removeClass("active");
      });
    }
  },

  collection_banner_initor : function(){ // Remove three banners on sub-collections page
    if(jQuery('.subcollections-three-banners .row').children().length <= 0){
      $('.subcollections-three-banners').remove();
    }
  },

  productButtonListMode : function(){ // hanlde product button in list mode view]
    jQuery("body").on("click", ".plm-add-to-cart", function() {
      let e = jQuery(this).closest(".product-wrapper");
      e.find('.btn-add-cart').trigger('click');
    });
  },

  fixTitle : function(){ // fix title a in filter
    jQuery(".rt a").attr("data-title", function() { return jQuery(this).attr("title"); });
    jQuery(".rt a").removeAttr("title");
    jQuery(".size-all").after(jQuery(".size-xxxl")).after(jQuery(".size-xxl")).after(jQuery(".size-xl")).after(jQuery(".size-l")).after(jQuery(".size-m")).after(jQuery(".size-s")).after(jQuery(".size-xs")).after(jQuery(".size-xxs")).after(jQuery(".size-xxxs"));
  },

  filterCatalogReplace : function(collectionUrl, filter_id){

    var value = collectionUrl.substring(collectionUrl.lastIndexOf('/') + 1);
    var val = value.substring(value.lastIndexOf('?'));

    collectionUrl = collectionUrl.replace(value, '');

    value = value.replace(val, '');
    value = value.replace('#', '');

    var value_arr = value.split('+');

    var current_arr = [];
    jQuery('#'+filter_id+' li.active-filter').each( function() {
      current_arr.push(jQuery(this).attr('data-handle'));
    });

    jQuery('#'+filter_id+' li.active-filter').find('a').attr('title', '');
    jQuery('#'+filter_id+' li').removeClass('active-filter');

    for(jQueryi = 0; jQueryi<current_arr.length; jQueryi++) {
      value_arr = jQuery.grep(value_arr, function( n, i ) { return ( n !== current_arr[jQueryi]  ); });
    }

    var new_data = value_arr.join('+')

    var new_url = collectionUrl+new_data+val;

    if( typeof AT_Filter != 'undefined' && AT_Filter ){
      AT_Filter.updateURL = true;
            AT_Filter.requestPage(new_url);
    }else{
      window.location = new_url;
    }

  },

  filterCatalog : function(){
      var currentTags = ''
      ,filters  = jQuery('.advanced-filter');

      filters.each(function() {
          var el = jQuery(this)
          ,group = el.data('group');

          if ( el.hasClass('active-filter') ) { //Remove class hidden
            el.parents('.sb-filter').find('a.clear-filter').removeClass('hidden');
          }
      });

      if($('body').hasClass('templateCollection') && $('#col-main .cata-product').length < 1 ){
        $('#col-main').append('<a href="javascript:history.go(-1)" style="text-decoration: underline;">Go Back</a>');
      }

      filters.on('click', function(e) {
        var el = $(this)
        ,group = el.data('group')
        ,url = el.find('a').attr('href')

        // Continue as normal if we're clicking on the active link
        if ( el.hasClass('active-filter') ) {
            return;
        }

        var _logic = jQuery(".page-cata").data('logic');

        if( _logic ){
            // Get active group link (unidentified if there isn't one)
            activeTag = $('.active-filter[data-group="'+ group +'"]');

            // If a tag from this group is already selected, remove it from the new tag's URL and continue
            if ( activeTag && activeTag.data('group') === group ) {
              e.preventDefault();
              activeHandle = activeTag.data('handle') + '+';

              // Create new URL without the currently active handle
              url = url.replace(activeHandle, '');

              window.location = url;
            }
        }

      });

      jQuery('.advanced-filters').each(function(index) {
          let _length = $(this).find('li');
          if((_length).length < 2){
            jQuery(this).parents('.sbw-filter').css('display', 'none');
            jQuery(this).parents('.filter-sidebar').css('display', 'none');
          }
      });

      jQuery('.sb-filter').on('click', '.clear-filter', function(n){ // Handle button clear

      var filter_id = jQuery(this).attr('id');
      filter_id = filter_id.replace('clear-', '');

      var collectionUrl = window.location.href;

      if(collectionUrl.match(/\?/)){
        var string = collectionUrl.substring(collectionUrl.lastIndexOf('?') - 1);

        if(string.match(/\//)){
          var str_replace = string.replace(/\//, '');
          collectionUrl = collectionUrl.replace(string, '');
          collectionUrl = collectionUrl+str_replace;
          AT_Main.filterCatalogReplace(collectionUrl, filter_id);
        }
        else{
          AT_Main.filterCatalogReplace(collectionUrl, filter_id);
        }
      }
      else{
        var value = collectionUrl.substring(collectionUrl.lastIndexOf('/') + 1);

        collectionUrl = collectionUrl.replace(value, '');

        value = value.replace('#', '');

        var value_arr = value.split('+');

        var current_arr = [];
        jQuery('#'+filter_id+' li.active-filter').each( function() {
          current_arr.push(jQuery(this).attr('data-handle'));
        });

        jQuery('#'+filter_id+' li.active-filter').find('a').attr('title', '');
        jQuery('#'+filter_id+' li').removeClass('active-filter');

        for(jQueryi = 0; jQueryi<current_arr.length; jQueryi++) {
          value_arr = jQuery.grep(value_arr, function( n, i ) { return ( n !== current_arr[jQueryi]  ); });
        }

        var new_data = value_arr.join('+')

        var new_url = collectionUrl+new_data;

        if( typeof AT_Filter != 'undefined' && AT_Filter ){
          AT_Filter.updateURL = true;
                AT_Filter.requestPage(new_url);
        }else{
          window.location = new_url;
        }
      }

      });
  },

  swatch : function(){
        jQuery('.swatch :radio').change(function() {
            var optionIndex = jQuery(this).closest('.swatch').attr('data-option-index');
            var optionValue = jQuery(this).val();
            jQuery(this)
            .closest('form')
            .find('.single-option-selector')
            .eq(optionIndex)
            .val(optionValue)
            .trigger('change');
        });
    },

  listCollections: function() { // hanlde sub collections in list collections section
      jQuery('.list-collection-section .sub-collections').each(function() {
        if($(this).length){
          let _parent = $(this).closest('.item');
          _parent.addClass('sub-collections-true');
        }
      })
  },

  slickProductPage: function(){

      jQuery('.page-product.slider-normal .slider-for-01').length && jQuery('.page-product.slider-normal .slider-for-01').slick({
        slidesToShow: 1
        ,slidesToScroll: 1
        ,rtl: jQuery('body').data('rtl')
        ,arrows: true
        ,fade: true
        ,asNavFor: '.slider-thumbs-01'
        ,nextArrow: $('.slick-btn-01 .btn-next')
        ,prevArrow: $('.slick-btn-01 .btn-prev')
      });

      jQuery('.page-product.slider-normal .slider-thumbs-01').length && jQuery('.page-product.slider-normal .slider-thumbs-01').slick({
        infinite: false
        ,vertical: true
        ,slidesToShow: 9
        ,slidesToScroll: 1
        ,rtl: jQuery('body').data('rtl')
        ,asNavFor: '.slider-for-01'
        ,dots: false
        ,arrows: false
        ,focusOnSelect: true
        ,responsive: [
          {
            breakpoint: 992,
            settings: {
              slidesToShow: 5
              ,vertical: false
            }
          },
          {
            breakpoint: 768,
            settings: {
              slidesToShow: 9
              ,vertical: false
            }
          },
          {
            breakpoint: 600,
            settings: {
              slidesToShow: 7
              ,vertical: false
            }
          },
          {
            breakpoint: 480,
            settings: {
              slidesToShow: 5
              ,vertical: false
            }
          }
        ]
      });

      jQuery('.page-product.layout-v6 .slider-for-01').length && jQuery('.page-product.layout-v6 .slider-for-01').slick({
        slidesToShow: 1
        ,slidesToScroll: 1
        ,rtl: jQuery('body').data('rtl')
        ,arrows: true
        ,fade: true
        ,asNavFor: '.slider-thumbs-01'
        ,nextArrow: $('.slick-btn-01 .btn-next')
        ,prevArrow: $('.slick-btn-01 .btn-prev')
      });

      jQuery('.page-product.layout-v6  .slider-thumbs-01').length && jQuery('.page-product.layout-v6  .slider-thumbs-01').slick({
        slidesToShow: 9
        ,slidesToScroll: 1
        ,rtl: jQuery('body').data('rtl')
        ,asNavFor: '.slider-for-01'
        ,dots: false
        ,arrows: false
        ,focusOnSelect: true
      });

      jQuery('.slider-for-03').length && jQuery('.slider-for-03').slick({
        rows: 1
        ,infinite: true
        ,slidesPerRow: 3
        ,slidesToScroll: 1
        ,rtl: jQuery('body').data('rtl')
        ,arrows: true
        ,fade: true
        ,nextArrow: $('.slick-btn-03 .btn-next')
        ,prevArrow: $('.slick-btn-03 .btn-prev')
        ,responsive: [
          {
            breakpoint: 576,
            settings: {
              slidesPerRow: 2
            }
          }
        ]
      });

      jQuery('.slider-for-07').length && jQuery('.slider-for-07').slick({
        rows: 2
        ,slidesPerRow: 2
        ,slidesToScroll: 1
        ,rtl: jQuery('body').data('rtl')
        ,arrows: true
        ,fade: true
        ,nextArrow: $('.slick-btn-07 .btn-next')
        ,prevArrow: $('.slick-btn-07 .btn-prev')
      });
  },
  
  productPage_variantFilter : function(groupImage){
      jQuery('#slide--main').attr('data-filter',groupImage);
      if (jQuery('.slider-filter').hasClass('slick-initialized')) {
        jQuery('.slider-filter .slick-slide').each(function() {
          let _group_class = jQuery(this).find('.slick-item').attr('data-match');
          jQuery(this).addClass(_group_class);
        });
        if (groupImage == 'none-group') {
          jQuery('.slider-filter').slick('slickUnfilter');

        }else{
          jQuery('.slider-filter').slick('slickUnfilter');
          jQuery('.slider-filter').slick('slickFilter','.'+groupImage+',.group-all');
          jQuery('.slider-filter').attr('data-filter','.'+groupImage);
        }
      }
    },

  scrollToReview : function(){ // scroll to review form on product page
    $('.rating-links a').click(function() {
      if($('.panel-accordion-review').length > 0){
        $('#product-accordion').scrollToMe();
        $('#tab_review').trigger('click');
      }
      else{
        $('.product-simple-tab ul li a').removeClass('active');
        $('#tab_review_tabbed a').addClass('active');
        $('.product-simple-tab .tab-content .tab-pane').removeClass('active');
        $('#tab-review').addClass('active');
        $('#tab_review_tabbed').scrollToMe();
      }
      return false;
    });
  },

  footerMenuMobile : function(){ // Handle footer menu on mobile
    jQuery(document).on('click','.footer-menu h6',function(){
      $(this).closest('.footer-menu').toggleClass('active');
    });

    jQuery('.footer-check-content').each(function() {
      var _this = $(this);
      if(_this.has( "div" ).length < 1){
        _this.parent().remove();
      }
    })
  },

  deadLine_time : function(){
    var _deadline_time = parseInt($('.shipping-time').attr('data-deadline'));
    var _currentDate = new Date();

    var _dueDate = new Date( _currentDate.getFullYear(), _currentDate.getMonth(), _currentDate.getDate());
    _dueDate.setHours(_deadline_time);

    switch(_currentDate.getDay()) {
      case 0: // Sunday
        _dueDate.setDate(_dueDate.getDate() + 1);
        break;

      case 5: // Friday
        if(_currentDate >= _dueDate){
          _dueDate.setDate(_dueDate.getDate() + 3);          }
        break;

      case 6: // Saturday
        _dueDate.setDate(_dueDate.getDate() + 2);
        break;

      default:
        if(_currentDate >= _dueDate){
          _dueDate.setDate(_dueDate.getDate() + 1);
        }
    }

    $('.countdown_deadline').countdown({until: _dueDate, format: 'HMS', padZeroes: true});
  },

  delivery_time : function(){
    var today = new Date();
    var business_days = parseInt($('.shipping-time').attr('data-deliverytime'));
    var deliveryDate = today; //will be incremented by the for loop
    var total_days = business_days; //will be used by the for loop

    for(var days=1; days <= total_days; days++) {
      deliveryDate = new Date(today.getTime() + (days *24*60*60*1000));
      if(deliveryDate.getDay() == 0 || deliveryDate.getDay() == 6) {
        //it's a weekend day so we increase the total_days of 1
        total_days++
      }
    }

    var weekday = new Array(7);
    weekday[0] =  "Sunday";
    weekday[1] = "Monday";
    weekday[2] = "Tuesday";
    weekday[3] = "Wednesday";
    weekday[4] = "Thursday";
    weekday[5] = "Friday";
    weekday[6] = "Saturday";
    var _day = weekday[deliveryDate.getDay()];

    var month = new Array();
    month[0] = "January";
    month[1] = "February";
    month[2] = "March ";
    month[3] = "April";
    month[4] = "May";
    month[5] = "June";
    month[6] = "July";
    month[7] = "August";
    month[8] = "September";
    month[9] = "October";
    month[10] = "November";
    month[11] = "December";
    var _month = month[deliveryDate.getMonth()];

    $('.delivery-time').html('Want it delivered by' + '&nbsp;' + '<strong>' + _day + ',' + '&nbsp;' + deliveryDate.getDate() + '&nbsp;' + _month + ' ?' + '</strong>');
  },

  scareWidth : function(){
      var _name_width = 110;
      jQuery('.variants-wrapper .selector-wrapper').find('label').each(function( index,value ){
        _name_width = jQuery(value).width() > _name_width ? jQuery(value).outerWidth() : _name_width;
      });
      jQuery('.variants-wrapper .selector-wrapper').find('label').css('width',_name_width);
      jQuery('.swatch.size').find('.header').css('width',_name_width);
      jQuery('.swatch.color, .swatch.colour').find('.header').css('width',_name_width);
      jQuery('.product-qty, .quantity').find('label').css('width',_name_width);
  },

  termsConditions : function(){ // handle check box terms & conditions on cart page
      jQuery('body').on('click', '[name="checkout"], [name="goto_pp"], [name="goto_gc"]', function() {

        if ($('.agree-terms-condition').is(':checked')) {
          $(this).submit();
        }
        else {
          alert("You must AGREE with Terms and Conditions.");
          return false;
        }
      });
  },

  newsletterTermsConditions : function(){ // handle check box terms & conditions on cart page
    jQuery('body').on('click', '.email-submit', function() {

      if ($('.newsletterCheck').is(':checked')) {
        $(this).submit();
      }
      else {
        alert("You must AGREE with Terms and Conditions.");
        return false;
      }
    });
  },

  leftColumnHandle : function(){ // Remove container for main column
    if($('#home-left-column').length){
      jQuery('#home-main-content .shopify-section').each(function() {
        $(this).find('.container').removeClass('container');
      })
    }
  }

  ,carousle_resp : function(_carousel_properties, e = 0){
    let resp;
    switch (e) {

      case '2':
        resp = {
          0     :{items: +_carousel_properties.attr('data-items-1')}
          ,992  :{items: +_carousel_properties.attr('data-items-2')}
        }
        break;
      case '4.1':
        resp = {
          0     :{items: +_carousel_properties.attr('data-items-1')}
          ,375  :{items: +_carousel_properties.attr('data-items-2')}
          ,1024 :{items: +_carousel_properties.attr('data-items-3')}
          ,1199 :{items: +_carousel_properties.attr('data-items-4')}
        }
        break;
      case '4.2':
        resp = {
          0     :{items: +_carousel_properties.attr('data-items-1')}
          ,375  :{items: +_carousel_properties.attr('data-items-2')}
          ,600  :{items: +_carousel_properties.attr('data-items-3')}
          ,1024 :{items: +_carousel_properties.attr('data-items-4')}
        }
        break;
      case '5':
        resp = {
          0     :{items: +_carousel_properties.attr('data-items-1')}
          ,375  :{items: +_carousel_properties.attr('data-items-2')}
          ,768  :{items: +_carousel_properties.attr('data-items-3')}
          ,1024 :{items: +_carousel_properties.attr('data-items-4')}
          ,1200 :{items: +_carousel_properties.attr('data-items-5')}
        };
        break;
      case '5.1':
        resp = {
          0     :{items: +_carousel_properties.attr('data-items-1')}
          ,600  :{items: +_carousel_properties.attr('data-items-2')}
          ,1000 :{items: +_carousel_properties.attr('data-items-3')}
          ,1100 :{items: +_carousel_properties.attr('data-items-4')}
          ,1200 :{items: +_carousel_properties.attr('data-items-5')}
        };

        break;
      case '5.2':
        resp = {
          0     :{items: +_carousel_properties.attr('data-items-1')}
          ,480  :{items: +_carousel_properties.attr('data-items-2')}
          ,768  :{items: +_carousel_properties.attr('data-items-3')}
          ,992  :{items: +_carousel_properties.attr('data-items-4')}
          ,1200 :{items: +_carousel_properties.attr('data-items-5')}
        };

        break;
      case '5.3':
        resp = {
          0     :{items: +_carousel_properties.attr('data-items-1')}
          ,375  :{items: +_carousel_properties.attr('data-items-2')}
          ,600  :{items: +_carousel_properties.attr('data-items-3')}
          ,992  :{items: +_carousel_properties.attr('data-items-4')}
          ,1025 :{items: +_carousel_properties.attr('data-items-5')}
        };

        break;
      case '8.1':
        resp = {
          0     :{items: +_carousel_properties.attr('data-items-1') }
          ,375  :{items: +_carousel_properties.attr('data-items-2') }
          ,768  :{items: +_carousel_properties.attr('data-items-3') }
          ,992  :{items: +_carousel_properties.attr('data-items-4') }
          ,1100 :{items: +_carousel_properties.attr('data-items-5') }
          ,1200 :{items: +_carousel_properties.attr('data-items-6') }
          ,1300 :{items: +_carousel_properties.attr('data-items-7') }
          ,1400 :{items: +_carousel_properties.attr('data-items-8') }
        }
        break;
      case '8.2':
        resp = {
          0     :{items: +_carousel_properties.attr('data-items-1')}
          ,600  :{items: +_carousel_properties.attr('data-items-2')}
          ,1000 :{items: +_carousel_properties.attr('data-items-3')}
          ,1100 :{items: +_carousel_properties.attr('data-items-4')}
          ,1200 :{items: +_carousel_properties.attr('data-items-5')}
          ,1300 :{items: +_carousel_properties.attr('data-items-6')}
          ,1400 :{items: +_carousel_properties.attr('data-items-7')}
          ,1500 :{items: +_carousel_properties.attr('data-items-8')}
        }
        break;
      case '8.3':
        resp = {
          0     :{items: +_carousel_properties.attr('data-items-1')}
          ,375  :{items: +_carousel_properties.attr('data-items-2')}
          ,480  :{items: +_carousel_properties.attr('data-items-3')}
          ,576  :{items: +_carousel_properties.attr('data-items-4')}
          ,600  :{items: +_carousel_properties.attr('data-items-5')}
          ,768  :{items: +_carousel_properties.attr('data-items-6')}
          ,992  :{items: +_carousel_properties.attr('data-items-7')}
          ,1024 :{items: +_carousel_properties.attr('data-items-8')}
        }
        break;
      default:
        resp = {
          0     :{items: +_carousel_properties.attr('data-items-1')}
          ,375  :{items: +_carousel_properties.attr('data-items-2')}
          ,768  :{items: +_carousel_properties.attr('data-items-3')}
          ,1024 :{items: +_carousel_properties.attr('data-items-4')}
        }
        break;
    }

    return resp;
  }

  ,init_carousel : function(){
    $('input[name="carousel_properties"]').length && $('input[name="carousel_properties"]').each((i,v)=>{
      let _carousel_properties = $(v);

      if (!$(_carousel_properties.attr('data-id')).hasClass('owl-loaded') && $(_carousel_properties.attr('data-id')).length ) {

        let _rsp = AT_Main.carousle_resp(_carousel_properties, _carousel_properties.attr('data-resp')) || {};

        $(_carousel_properties.attr('data-id')).owlCarousel({
          nav         : JSON.parse((_carousel_properties.attr('data-nav') || false ))
          ,dots       : JSON.parse((_carousel_properties.attr('data-dot') || false ))
          ,margin     : +_carousel_properties.attr('data-margin') || 0
          ,responsive : _rsp
          ,rtl        : jQuery('body').data('rtl')
        })
      }
    })
  }

  ,init_insta : function(){
    if( 'undefined' === typeof Instafeed ){
      console.log(" Instafeed has not defined yet! ");
      return;
    }

    $('.instagram_list').length && $('.instagram_list').each((i,v)=>{
      let _this = $(v) ,instagram_list;
      if (!_this.hasClass('insta-loaded')) {
        instagram_list = new Instafeed({
          get: "user"
          ,target       : "instagram_list_"+_this.data('id')
          ,accessToken  : _this.data('token-key')
          ,userId       : _this.data('uid')
          ,limit        : +_this.attr('data-limit')
          ,resolution   : "low_resolution"
          ,resolution2  : "standard_resolution"
          ,template   : $('.insta_layout[data-id="'+_this.data('id')+'"]').html()
          ,after: function() {
            _this.children('a').each(function(index,value){
              jQuery(value).attr("target","_blank");
            });
            let _carouselElement = $('input#carousel_'+_this.data('id'));
            if (_carouselElement.length) {
              _carouselElement.attr('name', _carouselElement.attr('name').replace('_disabled', ''));
              AT_Main.init_carousel();
              _carouselElement.attr('name', _carouselElement.attr('name')+'_disabled');
            }
            _this.addClass('insta-loaded');
          }
        });

        instagram_list.run();
      }
    })
  }
  ,reload_sections : function(){
    AT_Main.init_carousel();

    $('input[name="masonry_properties"]').length && $('input[name="masonry_properties"]').each((i,v)=>{
      let _masonry_properties = $(v);

      if (!$(_masonry_properties.attr('data-id')+'.murri').length) {
        let new_Muuri = (e,grid)=>{
          e = new Muuri(grid, {
            items: _masonry_properties.attr('data-element')
            ,layout: {
              fillGaps: true,
              rounding: false
            }
          })
        }

        $(_masonry_properties.attr('data-id')).each(function(){
          let $module = $(this)
          ,update = e=>new_Muuri($module, _masonry_properties.attr('data-id'));
          this.addEventListener('load', update, true);
          new_Muuri($module, _masonry_properties.attr('data-id'));
        });
      }
    })
  }
  ,init : function(){

    if( typeof _bc_config == 'undefined' ){
         console.log( " _bc_config is undefined " );
         return ;
    }

    this.stickMenu();
    this.toTopButton();
    this.newsletterPopup();
    this.newsletterCoupon();
    this.navMarginHeader();
    this.searchBox();
    this.smartSearch();
    this.toggleVerticalMenu();
    this.toggleCartSidebar();
    this.toggleFilterSidebar();
    this.handleSidebarWidthCollection();
    this.handleGridList();
    this.effectNavigation();
    this.menuOnMobileNew();
    this.megamenuWithTabs();
    this.megamenuDropwdownPosition();
    this.fixButton();
    this.menuOnMobile();
    this.handleMenuMultiLine();
    this.lookbooks_initor();
    this.collection_banner_initor();
    this.productButtonListMode();
    this.fixTitle();
    this.filterCatalog();
    this.listCollections();
    this.swatch();
    this.slickProductPage();
    this.footerMenuMobile();
  }
}

var AT_Slider ={

  owlSlider : function(){

        jQuery(".menu-proudct-carousel").length && jQuery(".menu-proudct-carousel").owlCarousel( {
          loop    : false,
          nav     : true,
          dots    : false,
          items   : 1,
          rtl     : jQuery('body').data('rtl'),
          navText : ['<span class="button-prev"></span>', '<span class="button-next"></span>']
        });

        jQuery(".image-carousel").length && jQuery('.image-carousel').owlCarousel({
            nav   : true,
            dots  : false,
            items : 1,
            rtl   : jQuery('body').data('rtl'),
            navText : ['<span class="button-prev"></span>', '<span class="button-next"></span>']
        });

        jQuery(".catalog-list").length && jQuery('.catalog-list').owlCarousel({
            nav     : true,
            dots    : false,
            items   : 3,
            rtl   : jQuery('body').data('rtl'),
            margin    : 30,
            responsive : {
                0:{
                  items: 1
                }
              ,480:{
                  items: 2
              }
                ,992:{
                  items: 3
                    ,nav  : false
              }
            },
            navText : ['<span class="button-prev"></span>', '<span class="button-next"></span>']
        });

        jQuery(".gallery-image-thumb").length && jQuery('.gallery-image-thumb').owlCarousel({
            nav     : true,
            dots    : false,
            items   : 4,
            rtl     : jQuery('body').data('rtl'),
            margin    : 20,
            mouseDrag : false,
            responsive  : {
                0:{
                  items: 2
                }
                ,480:{
                  items: 3
                }
                ,768:{
                  items: 4
                }
            },
            navText : ['<span class="button-prev"></span>', '<span class="button-next"></span>']

        });

        jQuery(".testimonial-carousel").length && jQuery('.testimonial-carousel').owlCarousel({
            nav   : false,
            dots  : true,
            items : 1,
            rtl   : jQuery('body').data('rtl')
        });

        jQuery(".box-product-carousel").length && jQuery('.box-product-carousel').owlCarousel({
            nav     : true,
            dots    : false,
            items   : 4,
            rtl     : jQuery('body').data('rtl'),
            margin    : 20,
            responsive  : {
                0:{
                  items: 2
                }
                ,600:{
                  items: 3
                }
                ,992:{
                  items: 4
                }
            },
            navText : ['<span class="button-prev"></span>', '<span class="button-next"></span>']

        });

        jQuery(".sb-product-grid").length && jQuery('.sb-product-grid').owlCarousel({
            nav   : true,
            dots  : false,
            items : 1,
            rtl   : jQuery('body').data('rtl'),
            navText : ['<span class="button-prev"></span>', '<span class="button-next"></span>']
        });

        jQuery(".sb-blog-grid").length && jQuery('.sb-blog-grid').owlCarousel({
            nav   : true,
            dots  : false,
            items : 1,
            rtl   : jQuery('body').data('rtl'),
            navText : ['<span class="button-prev"></span>', '<span class="button-next"></span>']
        });

        jQuery(".ct-banner-carousel").length && jQuery('.ct-banner-carousel').owlCarousel({
            nav   : true,
            dots  : false,
            items : 1,
            rtl   : jQuery('body').data('rtl'),
            navText : ['<span class="button-prev"></span>', '<span class="button-next"></span>']
        });

  }

  ,init : function(){
    this.owlSlider();
  }
}

var AT_AddCart = {

  addCartAction : function(){
    var _disable_ajax_cart = jQuery('.boxed-wrapper').data('ajax-cart');

    if(_disable_ajax_cart){
      $(document).on('click', '.add-to-cart', function(e) {
        var form = $(this).parents('form');
        form.submit();
      });
    }
    else{
      $("body").on( 'click','.add-to-cart', AT_AddCart.addToCart );
    }
  }

  ,addCart : function(){
    AT_Main.fixNoScroll();
    $('.cart-sb').toggleClass('opened');
    $('html,body').toggleClass('cart-opened');
  }

  ,notifyAddCartFail : function($i){
    $('.new-loading').removeClass('loading');
    $('.boxed-wrapper').append($i);
    $.fancybox.open('<div class="fancybox-error"><p>Exceeded maximum quantity available</p></div>')
  }

  ,addToCart : function(e){  // Ajax Add To Cart
    if (typeof e !== 'undefined') e.preventDefault();

    var $this = $(this);

    $this.addClass('disabled');

    var form = $this.parents('form');

    // Hide Modal
    $('.modal').modal('hide');

    $.ajax({
      type: 'POST',
      url: '/cart/add.js',
      async: true,
      data: form.serialize(),
      dataType: 'json',
      error: AT_AddCart.addToCartFail,
      success: AT_AddCart.addToCartSuccess,
      cache: false
    });

  }

  ,addToCartSuccess : function(jqXHR, textStatus, errorThrown){
    var _cart_style = jQuery('.boxed-wrapper').data('cart-style'),
        _redirect_checkout = jQuery('.boxed-wrapper').data('redirect');

    $('.add-to-cart').removeClass('disabled');

    $.ajax({
      type: 'GET',
      url: '/cart.js',
      async: false,
      cache: false,
      dataType: 'json',
      success: updateCartDesc
    });

    if(_cart_style == 'dropdown'){
      $('#layer-addcart-modal').show();

      var price = jqXHR['price'];
      var qty = jqXHR['quantity'];
      var total = price * qty;
      var addcart_modal_image = '<img src="'+ Shopify.resizeImage(jqXHR['image'], '150x') +'" alt="'+ jqXHR['title'] +'"/>';
      var addcart_modal_name = jqXHR['product_title'];
      var addcart_modal_variant = ""; if(jqXHR['variant_title'] != null) addcart_modal_variant = 'Variant: '+jqXHR['variant_title'];
      var addcart_modal_qty = '<strong>Qty:</strong>'+jqXHR['quantity'];
      var addcart_modal_price = Shopify.formatMoney(total, _bc_config.money_format);
      var addcart_modal_numpro = ""; if ($(".basket .number .n-item").html() == 1) addcart_modal_numpro = "There is 1 item in your cart."; else addcart_modal_numpro = "There are "+$(".basket .number .n-item").html()+" items in your cart.";

      //add data

      $('.addcart-modal-image').html(addcart_modal_image);
      $('.addcart-modal-title').html(addcart_modal_name);
      $('.addcart-modal-price').html(addcart_modal_price);
      $('.addcart-modal-variant').html(addcart_modal_variant);
      $('.addcart-modal-qty').html(addcart_modal_qty);
      $('.addcart-modal-number').html(addcart_modal_numpro);
      $('.addcart-modal-box').show();
    }

    else{
      AT_AddCart.addCart();
    }

    // Get the cart show in the cart box.
    Shopify.getCart(function(cart) {
      Shopify.updateCartInfo(cart, '#cart-info #cart-content');
    });

    if(_redirect_checkout){
      setTimeout(function(){
        window.location.href = "/checkout";
      }, 1200);
    }
  }

  ,addToCartFail : function (jqXHR, textStatus, errorThrown){
    $('.add-to-cart').removeClass('disabled');

    var response = $.parseJSON(jqXHR.responseText);
    var $i = '<div class="error">'+ response.description +'</div>';
    AT_AddCart.notifyAddCartFail($i);
  }

  ,addcartModalHide : function(){
    jQuery("#layer-addcart-modal").addClass("zoomOut animated").fadeOut();
    jQuery("#layer-addcart-modal").removeClass("zoomOut animated");
  }

  ,init : function(){
    this.addCartAction();
  }
}

jQuery.fn.extend({
  scrollToMe: function() {
    if (jQuery(this).length) {
      var top = jQuery(this).offset().top - 200;
      jQuery('html,body').animate({
        scrollTop: top
      }, 500);
    }
  },
});;

/* Handle when window resize */
jQuery(window).resize(function() {

  AT_Main.handleSidebarWidthCollection();

  /* Reset sticky menu */
  AT_Main.stickMenu();

  /* Reset Page when fixNoScroll had called before */
  AT_Main.fixReturnScroll();

  if(AT_Main.getWidthBrowser() > 992 && jQuery('.menu-mobile').hasClass('opened'))
    jQuery("#body-content").trigger('click');

  if(AT_Main.getWidthBrowser() > 992){
    AT_Main.megamenuDropwdownPosition();
  }

  AT_Main.navMarginHeader();

});

jQuery(document).ready(function($) {
  var i_sections = new theme.Sections();

  $('.currency-selector select').on('change', function() {
    $(this).parents('form').submit();
  });

  AT_Main.init();
  AT_Slider.init();
  AT_AddCart.init();

  i_sections.register('reload_section' ,AT_Main.reload_sections);  
  i_sections.register('reload_insta'   ,AT_Main.init_insta);
  
  i_sections.register('reload_newsletter' ,function(){
    $('#newsletter-popup').closest('.shopify-section').on('shopify:section:select'   ,function(){
      $('.fancybox-container.fancybox-is-open').remove();
      
      !$('.fancybox-container').length && $.fancybox.open({
        src  : '#newsletter-popup'
        ,type : 'inline'
        ,autoDimensions: false
        ,width    : 'auto'
        ,height   : 'auto'
        ,closeBtn    : false
      })
    })
    .on('shopify:section:deselect' ,function(){
      
    });

    $("#newsletter-popup .block-coupon").on('shopify:block:deselect', function(){
      jQuery('.text-box-image').show();
      jQuery('.subscribe-result').hide();
      let _image = jQuery('#newsletter-popup .newsletter-popup-content').data('image');
      jQuery('.newsletter-popup-content').addClass('block-image-'+_image).removeClass('block-image-false');
    })
    .on('shopify:block:select', function(){
      jQuery('.text-box-image').hide();
      jQuery('.subscribe-result').show();
      jQuery('.newsletter-popup-content').removeClass('block-image-true').addClass('block-image-false');
    });
  });
});